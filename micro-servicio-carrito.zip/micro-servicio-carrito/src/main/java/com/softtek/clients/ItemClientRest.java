package com.softtek.clients;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.softtek.models.Item;

@FeignClient(name = "servicio-item")
public interface ItemClientRest {
	
//	@GetMapping("/listar")
//	public List<Item> listar();
	
	@GetMapping("/ver/{id}/cantidad/{cantidad}" )
	public Item agregar(@PathVariable Long id, @PathVariable Integer cantidad);

}
