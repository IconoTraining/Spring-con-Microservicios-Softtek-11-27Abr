package com.softtek.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.softtek.models.Carrito;
import com.softtek.services.CarritoService;

@RestController
public class CarritoController {
	
	@Autowired
	private CarritoService carritoService;
	
	
	// http://localhost:8003/crear/Pepito
	@GetMapping("/crear/{usuario}")
	public Carrito crear(@PathVariable String usuario) {
		return carritoService.crear(usuario);
	}
	
	// http://localhost:8003/agregar/id/3/cantidad/50/usuario/Pepito
	@GetMapping("/agregar/id/{id}/cantidad/{cantidad}/usuario/{usuario}")
	public void agregarItem(@PathVariable Long id, @PathVariable Integer cantidad, 
			@PathVariable String usuario) {
		carritoService.agregarItem(id, cantidad, usuario);
	}
	
	// http://localhost:8003/buscar/Pepito
	@GetMapping("/buscar/{usuario}")
	public Carrito buscar(@PathVariable String usuario) {
		return carritoService.buscar(usuario);
	}
	
	// http://localhost:8003/sacar/id/3/usuario/Pepito
	@GetMapping("/sacar/id/{id}/usuario/{usuario}")
	public void sacarItem(@PathVariable Long id, @PathVariable String usuario) {
		carritoService.eliminarItem(id, usuario);
	}

}
