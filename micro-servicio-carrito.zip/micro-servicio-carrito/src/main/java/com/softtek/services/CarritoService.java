package com.softtek.services;

import com.softtek.models.Carrito;

public interface CarritoService {
	
	Carrito crear(String usuario);
	void agregarItem(Long id, Integer cantidad, String usuario);
	Carrito buscar(String usuario);
	void eliminarItem(Long id, String usuario);

}
