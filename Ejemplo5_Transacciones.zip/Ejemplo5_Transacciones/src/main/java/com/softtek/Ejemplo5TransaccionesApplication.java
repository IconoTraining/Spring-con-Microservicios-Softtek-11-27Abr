package com.softtek;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.softtek.persistence.Producto;
import com.softtek.persistence.ProductoDAO;

@SpringBootApplication
public class Ejemplo5TransaccionesApplication implements CommandLineRunner{
	
	@Autowired
	private ProductoDAO dao;

	@Override
	public void run(String... args) throws Exception {
		List<Producto> lista = new ArrayList<>();
		lista.add(new Producto(1L, "Monitor", 139.50));
		lista.add(new Producto(2L, "Teclado", 50));
		lista.add(new Producto(3L, "Raton", 50));
		lista.add(new Producto(1L, "Monitor", 200));
		
		
		insertar(lista);
				
	}
	
	@Transactional(propagation = Propagation.REQUIRED,
		    isolation = Isolation.SERIALIZABLE,
		    rollbackFor = Exception.class)
	public void insertar(List<Producto> lista) {
		for(Producto producto : lista) {
			if ("Raton".equals(producto.getDescripcion())) {
				throw new RuntimeException("Probando la transaccion");
			}
			dao.save(producto);
			System.out.println("Producto guardado: " + producto.getDescripcion());
		}
	}
	
	public static void main(String[] args) {
		SpringApplication.run(Ejemplo5TransaccionesApplication.class, args);
	}

}
