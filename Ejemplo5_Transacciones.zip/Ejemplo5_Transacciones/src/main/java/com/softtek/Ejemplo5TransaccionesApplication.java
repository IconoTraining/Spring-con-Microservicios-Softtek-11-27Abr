package com.softtek;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.softtek.persistence.Producto;
import com.softtek.persistence.ProductoDAO;

@SpringBootApplication
public class Ejemplo5TransaccionesApplication implements CommandLineRunner{
	
	@Autowired
	private ProductoDAO dao;

	@Override
	public void run(String... args) throws Exception {
		List<Producto> lista = new ArrayList<>();
		lista.add(new Producto(1L, "Monitor", 139.50));
		lista.add(new Producto(2L, "Teclado", 50));
		lista.add(new Producto(3L, "Raton", 50));
		
		// No genera error, si la PK existe se modifica ese registro
		lista.add(new Producto(1L, "Monitor", 200));
		
		// Si creo un producto vacio, que no tiene PK eso si genera error
		lista.add(new Producto());
		
		try {
			insertar(lista);
		} catch (Exception e) {
			System.out.println("Ha ocurrido un error");
		}	
				
	}
	
	@Transactional(propagation = Propagation.REQUIRED,
		    isolation = Isolation.SERIALIZABLE,
		    rollbackFor = Exception.class)
	public void insertar(List<Producto> lista) {
		/*
		for(Producto producto : lista) {
			// El metodo save gestiona cada transaccion de forma independiente
			dao.save(producto);
		}*/
		
		// El metodo saveAll se gestiona como transaccion unica 
		// Gracias Jorge Gonzalez
		dao.saveAll(lista);
	}
	
	public static void main(String[] args) {
		SpringApplication.run(Ejemplo5TransaccionesApplication.class, args);
	}

}
