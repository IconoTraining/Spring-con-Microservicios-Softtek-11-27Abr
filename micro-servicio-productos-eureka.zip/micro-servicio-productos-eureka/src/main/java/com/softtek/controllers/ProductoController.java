package com.softtek.controllers;

import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.softtek.models.entity.Producto;
import com.softtek.service.IProductoService;

@RestController
public class ProductoController {
	
	@Autowired
	private IProductoService productoService;
	
	// Esta opcion no funciona con puerto dinamico
	@Value("${server.port}")
	private Integer port;
	
	@Autowired
	private HttpServletRequest request;
	
	// http://localhost:8001/listar
	@GetMapping("/listar")
	public List<Producto> listar(){
		return productoService.consultarTodos()
				.stream()
				.map(p -> {
					//p.setPort(port);
					p.setPort(request.getLocalPort());
					return p;
				}).collect(Collectors.toList());
	}
	
	// http://localhost:8001/buscar/2
	@GetMapping("/buscar/{id}")
	public Producto buscar(@PathVariable Long id) {
		Producto producto = productoService.buscarProducto(id);
		//producto.setPort(port);
		producto.setPort(request.getLocalPort());
		return producto;
	}

}
