package com.softtek;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.softtek.persistence.Producto;
import com.softtek.persistence.ProductoDAO;

@SpringBootApplication
public class Ejemplo3JpaRestApplication implements CommandLineRunner{
	
	@Autowired
	private ProductoDAO dao;

	@Override
	public void run(String... args) throws Exception {
		System.out.println("Numero de registros: "+ dao.count());
		
		System.out.println("Todos los productos");
		System.out.println("-------------------");
		for(Producto p : dao.findAll()) {
			System.out.println(p);
		}
		
		Producto nuevo = dao.save(new Producto("Prueba", 1000));
		
		dao.findById(6L).ifPresent(encontrado -> dao.delete(encontrado));
		
		
	}
	
	public static void main(String[] args) {
		SpringApplication.run(Ejemplo3JpaRestApplication.class, args);
	}

}
