insert into productos (descripcion, precio) values ('Monitor', 129.50);
insert into productos (descripcion, precio) values ('Teclado', 50);
insert into productos (descripcion, precio) values ('Raton', 50);
insert into productos (descripcion, precio) values ('Impresora', 89.95);
insert into productos (descripcion, precio) values ('Pizarra digital', 500);