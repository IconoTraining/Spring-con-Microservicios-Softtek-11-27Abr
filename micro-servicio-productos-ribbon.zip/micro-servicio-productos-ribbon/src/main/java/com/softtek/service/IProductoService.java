package com.softtek.service;

import java.util.List;

import com.softtek.models.entity.Producto;

public interface IProductoService {
	
	List<Producto> consultarTodos();
	Producto buscarProducto(Long id);

}
