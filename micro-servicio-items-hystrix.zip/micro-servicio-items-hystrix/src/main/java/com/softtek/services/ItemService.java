package com.softtek.services;

import java.util.List;

import com.softtek.models.Item;

public interface ItemService {

	List<Item> consultarTodos();
	Item buscarItem(Long id, Integer cantidad);
	
}
