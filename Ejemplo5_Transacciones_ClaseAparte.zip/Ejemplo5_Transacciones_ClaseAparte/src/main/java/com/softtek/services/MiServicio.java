package com.softtek.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.softtek.persistence.Producto;
import com.softtek.persistence.ProductoDAO;

@Service
public class MiServicio {
	
	@Autowired
	private ProductoDAO dao;

	
	@Transactional(propagation = Propagation.REQUIRED,
		    isolation = Isolation.SERIALIZABLE,
		    rollbackFor = Exception.class)
	public void insertar(List<Producto> lista) {
		for(Producto producto : lista) {
			// Si esta en una clase aparte, el metodo save si que trabaja la transaccion como unica
			// y ejecuta rollback si se produce alguna excepcion
			dao.save(producto);
		}
		
	}

}
