package com.softtek;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.softtek.persistence.Producto;
import com.softtek.persistence.ProductoDAO;
import com.softtek.services.MiServicio;

@SpringBootApplication
public class Ejemplo5TransaccionesApplication implements CommandLineRunner{
	
	@Autowired
	private ProductoDAO dao;
	
	@Autowired
	private MiServicio miServicio;

	@Override
	public void run(String... args) throws Exception {
		List<Producto> lista = new ArrayList<>();
		lista.add(new Producto(1L, "Monitor", 139.50));
		lista.add(new Producto(2L, "Teclado", 50));
		lista.add(new Producto(3L, "Raton", 50));
		
		// No genera error, si la PK existe se modifica ese registro
		lista.add(new Producto(1L, "Monitor", 200));
		
		// Si creo un producto vacio, que no tiene PK eso si genera error
		lista.add(new Producto());
		
		try {
			miServicio.insertar(lista);
		} catch (Exception e) {
			System.out.println("Ha ocurrido un error");
		}	
				
	}
	
	
	public static void main(String[] args) {
		SpringApplication.run(Ejemplo5TransaccionesApplication.class, args);
	}

}
