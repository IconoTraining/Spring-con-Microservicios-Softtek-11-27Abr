package com.softtek;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

@SpringBootApplication
public class EjercicioConsumirGradosApplication {

	public static void main(String[] args) {
		SpringApplication.run(EjercicioConsumirGradosApplication.class, args);
	}
	
	@Bean
	public RestTemplate restTemplate(RestTemplateBuilder builder) {
		return builder.build();
	}
	
	@Bean
	public CommandLineRunner run(RestTemplate restTemplate) {
		return datos -> {
			double grados = restTemplate.getForObject(
					"http://localhost:8080/grados?fahrenheit=99.5", Double.class);
			System.out.println(grados + " Grados centigrados");
		};
	}

}
