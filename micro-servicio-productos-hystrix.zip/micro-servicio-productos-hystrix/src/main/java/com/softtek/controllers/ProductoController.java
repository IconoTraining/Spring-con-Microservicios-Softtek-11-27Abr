package com.softtek.controllers;

import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.softtek.models.entity.Producto;
import com.softtek.service.IProductoService;

@RestController
public class ProductoController {
	
	@Autowired
	private IProductoService productoService;
	
	// Esta opcion no funciona con puerto dinamico
	@Value("${server.port}")
	private Integer port;
	
	@Autowired
	private HttpServletRequest request;
	
	// http://localhost:8001/listar
	@GetMapping("/listar")
	public List<Producto> listar(){
		return productoService.consultarTodos()
				.stream()
				.map(p -> {
					//p.setPort(port);
					p.setPort(request.getLocalPort());
					return p;
				}).collect(Collectors.toList());
	}
	
	// http://localhost:8001/buscar/2
	@GetMapping("/buscar/{id}")
	public Producto buscar(@PathVariable Long id) throws InterruptedException {
		Producto producto = productoService.buscarProducto(id);
		//producto.setPort(port);
		producto.setPort(request.getLocalPort());
		
		
		// Provocar una excepcion que llegara al micro servicio items
		//if (id > 4) throw new RuntimeException("Error al buscar el producto");
		
		// Por defecto, los microservicios esperan un maximo de 1 segundo en obtener la respuesta
		// Si la peticion supera ese segundo devuelve un timeout.
		// Provocar un timeout, paro la ejecución 10 segundos
		//Thread.sleep(10000);
		
		
		return producto;
	}

}




