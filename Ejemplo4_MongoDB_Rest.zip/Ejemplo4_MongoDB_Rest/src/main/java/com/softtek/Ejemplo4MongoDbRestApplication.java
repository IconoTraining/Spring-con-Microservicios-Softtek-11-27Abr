package com.softtek;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.softtek.persistence.Producto;
import com.softtek.persistence.ProductoDAO;

@SpringBootApplication
public class Ejemplo4MongoDbRestApplication implements CommandLineRunner{
	
	private final ProductoDAO dao;
	
	
	public Ejemplo4MongoDbRestApplication(ProductoDAO dao) {
		this.dao = dao;
	}
	
	@Override
	public void run(String... args) throws Exception {
		//dao.deleteAll();
		
		// Alta de productos
		/*
		dao.save(new Producto("Raton", 50));
		dao.save(new Producto("Teclado", 50));
		dao.save(new Producto("Monitor", 139.50));
		dao.save(new Producto("Impresora", 85.95));
		dao.save(new Producto("Pizarra digital", 450));
		*/
		
		// Mostrar todos los productos
		System.out.println("Todos los productos");
		System.out.println("-------------------");
		for(Producto p: dao.findAll()) {
			System.out.println(p);
		}
		
		// Buscar un producto por id
		System.out.println("Buscar por ID: " + dao.findById("64382b29db0a281e1fc3e22a"));
		
		// Buscar por descripcion
		System.out.println("Raton: " + dao.findByDescripcion("Raton"));
		
		// Mostrar productos con precio entre 100 y 500
		System.out.println("Productos entre 100 y 500€");
		System.out.println("--------------------------");
		for(Producto p: dao.findByPrecioBetween(100, 500)) {
			System.out.println(p);
		}
		
		// Mostrar productos ordenados por descripcion descendente
		System.out.println("Productos por descripcion");
		System.out.println("--------------------------");
		for(Producto p: dao.OrderByDescripcionDesc()) {
			System.out.println(p);
		}
		
		// Productos de 50€ ordenados por descripcion descendente
		System.out.println("Productos por 50€");
		System.out.println("-----------------");
		for(Producto p: dao.findByPrecioOrderByDescripcionDesc(50)) {
			System.out.println(p);
		}
		
	}

	public static void main(String[] args) {
		SpringApplication.run(Ejemplo4MongoDbRestApplication.class, args);
	}

}
