package com.softtek.persistence;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

@RepositoryRestResource(collectionResourceRel = "productos", path = "productos")
public interface ProductoDAO extends MongoRepository<Producto, String>{

		// Mostrar todos los productos
		// http://localhost:8080/productos
		
		// Utilizamos los metodos heredados de CrudRepository
		// https://docs.spring.io/spring-data/jpa/docs/current/reference/html/
		
		// Podemos crear nuestros propios metodos utiliando palabras clave
		// https://docs.spring.io/spring-data/jpa/docs/current/reference/html/#repository-query-keywords
		
		// http://localhost:8080/productos/search/findByDescripcion?descripcion=Raton
		public List<Producto> findByDescripcion(String descripcion);
		
		// Buscar por precio ordenados por descripcion descendente
		// http://localhost:8080/productos/search/findByPrecioOrderByDescripcionDesc?precio=50
		public List<Producto> findByPrecioOrderByDescripcionDesc(double precio);
		
		// Buscar los productos por precio entre 100 y 500 € incluido
		// http://localhost:8080/productos/search/findByPrecioBetween?min=100&max=500
		public List<Producto> findByPrecioBetween(double min, double max);
		
		// Mostrar todos los productos ordenados por descripcion
		// http://localhost:8080/productos/search/OrderByDescripcionDesc
		public List<Producto> OrderByDescripcionDesc();
		
		// Todos los metodos implementados se pueden ver en esta url
		// http://localhost:8080/productos/search
}
